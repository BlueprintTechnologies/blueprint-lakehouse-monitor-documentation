param(
    [string]$BaseApplicationName,
    [string]$templateFileLocation = "$psScriptRoot\postDeploymentAppService.bicep",
    [string]$KeyvaultName,
    [string]$AppReplyURI,
    [string]$AppServiceName,
    [string]$resourcegroup,
    [int]$expirationTimeInSeconds,
    [string]$SubscriptionID)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

$requiredApplicationPermissions = @(
    <#@{
        # Azure Service management -- user_impersonation
        "resourceAppId"= "797f4846-ba00-4fd7-ba43-dac1f8f63013"
        "resourceAccess"=  @(
            @{
                "id"= "41094075-9dad-400e-a0bd-54e686782033"
                "type"= "Scope"
                'adhoc_friendly_name'= "Azure Service management -- user_impersonation"
            }
        ) 
    },
    @{ # azure databricks -- user_impersonation
        "resourceAppId"= "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"
        "resourceAccess"=  @(
            @{
                "id"= "739272be-e143-11e8-9f32-f2801f1b9fd1"
                "type"= "Scope"
                'adhoc_friendly_name'= "azure databricks -- user_impersonation"
            }
        )
        
    },
    #>
    @{ # Microsoft Graph
        "resourceAppId"= "00000003-0000-0000-c000-000000000000"
        "resourceAccess"=  @(
            @{
                "id"= "e1fe6dd8-ba31-4d61-89e7-88639da4683d"
                "type"= "Scope"
                'adhoc_friendly_name'= "Microsoft Graph -- User.Read"
            }
        )
        
    }
)
$params = @{
    adminConsentDescription = "Allow the application to access $BaseApplicationName on behalf of the signed-in user."
    adminConsentDisplayName = "Access $BaseApplicationName"
    isEnabled = $true
    id = new-guid   
    type = "User"
    userConsentDescription= "Allow the application to access $BaseApplicationName on your behalf."
    userConsentDisplayName= "Access $BaseApplicationName"
    value = "user_impersonation"
}
$oauthpermission = New-Object -TypeName "Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphPermissionScope" `
    -Property $params

$appapi = New-Object -TypeName "Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphApiApplication" `
-Property @{Oauth2PermissionScope = $oauthpermission}

Set-AzContext -Subscription $SubscriptionID | Out-Null  
try{
    $appinfo= Get-AzADApplication -DisplayName $BaseApplicationName
    if([string]::IsNullOrEmpty($appinfo)){
        # TODO splat these parameters
        #$web = New-Object -TypeName "Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphWebApplication"
        #$web.ImplicitGrantSetting.EnableIdTokenIssuance = $true
        write-host "Creating app registration `'$BaseApplicationName`'"
        $web = New-Object -TypeName "Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.MicrosoftGraphWebApplication"
        $web.ImplicitGrantSetting.EnableIdTokenIssuance = $true
        $appinfo = New-AzADApplication -DisplayName $BaseApplicationName -Api $appapi -ReplyUrls $AppReplyURI -Web $web
        # TODO: potentiall create a permissions scope .net object and apply these permissions at SP creation time instead of one-by-one
        # https://docs.microsoft.com/en-us/dotnet/api/microsoft.azure.powershell.cmdlets.resources.msgraph.models.apiv10.microsoftgraphpermissionscope.-ctor?view=az-ps-latest
        # permissions
        $appCredStartDate = [datetime]::Now
        $appCredEndtDate = [datetime]::Now.AddYears(5)
        $clientSecret = New-AzADAppCredential -ObjectId $appinfo.Id -StartDate $appCredStartDate -EndDate $appCredEndtDate
        try{
            foreach($resource in $requiredApplicationPermissions){
                foreach($entry in $resource.resourceAccess){
                    Add-AzADAppPermission -ApiId $resource.resourceAppId -PermissionId $entry.id -Type $entry.type -ApplicationId $appinfo.appID
                }    
            }
        }
        catch{
            Write-Error "Could not add application permission $($permission.adhoc_friendly_name) to application $BaseApplicationName`n$_"
        }
        Update-AzADApplication -ObjectId $appinfo.Id -IdentifierUri "api://$($appinfo.AppId)"
        Write-Host "Creating accompanying service principal for `'$BaseApplicationName`' registration"
        $spinfo = New-AzADServicePrincipal -ApplicationId $appinfo.AppId

    }
    else{
        $appCredStartDate = [datetime]::Now
        $appCredEndtDate = [datetime]::Now.AddYears(5)
        $clientSecret = New-AzADAppCredential -ObjectId $appinfo.Id -StartDate $appCredStartDate -EndDate $appCredEndtDate
        $spinfo = Get-AzADServicePrincipal -ApplicationId $appinfo.AppId
    }
}
catch{
    Write-Error "Could not create app registration $BaseApplicationName. `n$_"
    throw $_
}
#keyvault reference for msft auth id provider app secret


#post deployment template
try{
    $templateParameters = @{
        'KeyVaultName' = $KeyvaultName
        'AppRegistrationClientSecret' = $clientSecret.SecretText
    }
    if($expirationTimeInSeconds){
        $templateParameters.Add('expirationTimeInSeconds',$expirationTimeInSeconds)
    }
    $deploymentName = "postAppDeploymentConfig"
    Write-Output "Updating keyvault secrets"
    $output = New-AzResourceGroupDeployment -TemplateFile $templateFileLocation -ResourceGroupName $resourcegroup -TemplateParameterObject $templateParameters -Name $deploymentName
    Write-Output "App registration and associated configuration complete"
}
catch{
    throw $_
}

return @{'AppRegistrationAppID'=$appinfo.appID
        'SPClientID'=$spinfo.AppId
        'SPObjectID'=$spinfo.Id}
