param ($AppURL,
       $TenantID,
       $KeyvaultURL,
       $VMSysAssignedIdentity,
       $AppRegistrationAppID,
       $SPClientID,
       $SPObjectID,
       $StorageAccountName,
       $containerName,
       $SQLServerURL,
       $SQLUsername)

$setupContent = "
sudo apt update
sudo apt-get install -y docker.io docker-compose
"
$setupContent  | Out-File -FilePath "./SetupContent.txt" -Encoding utf8 -NoNewline 


$envFileContent = "

APPLICATION_LOG_HTTPHEADER=false
APPSERVICE_URL=$($AppURL)
AZURE_KEYVAULT_ENABLED=true
AZURE_KEYVAULT_TENANTID=$($TenantID)
AZURE_KEYVAULT_URI=$($KeyvaultURL)
AZURE_MANAGED_IDENTITY_ID=$($VMSysAssignedIdentity)
LOG_LEVEL=info
LOG_LEVEL_APP=debug
LOG_LEVEL_HTTP_HEADERS=error

# For vault secrets the following pattern should be used ${keyvault_secret_name}
# Value ${msft-provider-auth-secret} it's hardcoded in application-yml as with newer docker-compose versions
# this secret-name will be evaluated and will not be passed to docker-container as it is
#MICROSOFT_PROVIDER_AUTHENTICATION_SECRET=${msft-provider-auth-secret}
SERVICE_PRINCIPAL_CLIENTID=$($SPClientID)
SERVICE_PRINCIPAL_OBJECTID=$($SPObjectID)
SERVICE_PRINCIPAL_TENANTID=$($TenantID)

SQL_DATABASE=lakehouse
SQL_SERVER_HOST=$($SQLServerURL)
SQL_USER=$($SQLUsername)
# Value ${mssql-password} it's hardcoded in application-yml as with newer docker-compose versions
# this secret-name will be evaluated and will not be passed to docker-container as it is
#SQL_PASSWORD=${mssql-password}

# Placeholder ${storage-account-key} it's hardcoded in application-yml as with newer docker-compose versions
# this secret-name will be evaluated and will not be passed to docker-container as it is
# STORAGE_AZURE_ACCESS_KEY=${storage-account-key}
STORAGE_AZURE_ACCOUNT=$($StorageAccountName)
STORAGE_AZURE_CONTAINER=$($containerName)

SERVER_SSL_ENABLED=true

# SERVER_SSL_* env variables should not be copied to deployment scripts. It's an optional post-install step.
SERVER_SSL_KEY-STORE=/keystore/bplm.p12
SERVER_SSL_KEY-STORE-PASSWORD=
SERVER_SSL_KEY-STORE-TYPE=PKCS12
SERVER_SSL_KEY-ALIAS=bplm
SERVER_SSL_KEY-PASSWORD=

AUTHENTICATION_PROVIDER=active-directory
SERVER_SERVLET_SESSION_PERSISTENT=true
SERVER_SERVLET_SESSION_STORE-DIR=/spring-session/session"

$fileLocation = ".env"
Write-Output "Environment configuration file location $fileLocation"
$envFileContent  | Out-File -FilePath $fileLocation -Encoding utf8 -NoNewline 
