#!/usr/bin/env bash

if [ "a$1" == "a" ]; then
    echo "Docker user must be provided"
    exit 1
fi
if [ "a$2" == "a" ]; then
    echo "Docker pass  must be provided"
    exit 1
fi

DOCKER_USER=$1
DOCKER_PASS=$2

docker login blueprint.azurecr.io -u $DOCKER_USER -p $DOCKER_PASS
docker-compose up -d


