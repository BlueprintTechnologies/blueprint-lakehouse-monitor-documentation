# Handle app registration secret rotation
# handle storage account key
# handle sas uri for token stores
param(
      [Parameter(Mandatory=$true)]
      [string]$AppRegistrationName,

      [Parameter(Mandatory=$true)]
      [string]$SubscriptionID,

      [Parameter(Mandatory=$true)]
      [string]$ResourceGroupName,

      [Parameter(Mandatory=$true)]
      [string]$KeyVaultName,

      [Parameter(Mandatory=$true)]
      [string]$StorageAccountName,
      
      [int]$ExpiryLengthInDays = 97
)
      
$ErrorActionPreference = 'Stop'
$appSecretName = 'bplm-service-principal-clientSecret'
$storageKeySecretName = 'bplm-storage-access-key'
$tokenStoreSecretName = 'token-store-sasuri'
try{
    $currentSecretNames = (Get-AzKeyVaultSecret -VaultName $KeyVaultName).Name
}
catch{
    throw $_
}

Write-Output "Starting secret rotation for: `n$appSecretName`n$storageKeSecretName`n$tokenStoreSecretname"
try{
    Set-AzContext -Subscription $SubscriptionID 
}
catch{
    throw $_
}
$startDateTime = [datetime]::Now
$EndDateTime = [datetime]::Now.AddDays($ExpiryLengthInDays)

# storage key
try {
    Write-Output "Starting update for $storageKeySecretName"
    $newKey = (New-AzStorageAccountKey -name $StorageAccountName -KeyName key1 -ResourceGroupName $ResourceGroupName).keys[0].Value
    Set-AzKeyVaultSecret -VaultName $KeyVaultName -Name $storageKeySecretName -SecretValue ($newKey | convertto-securestring -AsPlainText -Force ) | out-null
    Write-Output "Completed update for $storageKeySecretName"
}
catch {
    throw $_
}
if($tokenStoreSecretName -in $currentSecretNames){
    try{
        Write-Output "Starting update for $tokenStoreSecretName"
        $storageContext = New-AzStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $newKey
        $newToken = New-AzStorageContainerSASToken -Name 'tokens' -Permission 'racwdl' -StartTime $startDateTime -ExpiryTime $EndDateTime -Context $storageContext 
        $sasURI = "https://$($StorageAccountName).blob.core.windows.net/tokens$($newToken)"
        $secretInfo = Set-AzKeyVaultSecret -VaultName $KeyVaultName -Name $tokenStoreSecretName -SecretValue ($sasURI | convertto-securestring -AsPlainText -Force )
        Write-Output "Completed update for $tokenStoreSecretName"
    }
    catch{
        throw $_
    }
}
else{
    Write-Output "Could not find secret $tokenStoreSecretName in $KeyvaultName"
}

# Create new app secret, save into keyvault
try{
    Write-Output "Starting update for $appSecretName"
    $appInfo = Get-AzADApplication -DisplayName $AppRegistrationName
    $clientSecret = New-AzADAppCredential -ObjectId $appinfo.Id -StartDate $startDateTime -EndDate $EndDateTime
    $secretInfo = Set-AzKeyVaultSecret -VaultName $KeyVaultName -Name $appSecretName -SecretValue ($clientSecret.SecretText | convertto-securestring -AsPlainText -Force )
}
catch{
    throw $_
}
