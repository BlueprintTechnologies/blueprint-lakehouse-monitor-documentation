#!/usr/bin/env bash

if [ "a$1" == "a" ]; then
    echo "FQDN must be provided"
    exit 1
fi

if [ "a$2" == "a" ]; then
    echo "BPLM version must be provided"
    exit 1
fi

ADMIN_EMAIL=azureadm@bpcs.com
FQDN=$1
BPLM_VERSION=$2

sudo apt update
sudo apt-get install -y docker.io docker-compose
sudo apt install -y certbot
yes "" | sudo certbot certonly --standalone --email ${ADMIN_EMAIL} --noninteractive --agree-tos --domain ${FQDN} --cert-name bplm
mkdir keystore
cd keystore
sudo cp -L /etc/letsencrypt/live/bplm/privkey.pem .
sudo cp -L /etc/letsencrypt/live/bplm/fullchain.pem .
sudo chown azureadm:azureadm privkey.pem fullchain.pem
openssl pkcs12 -export -in fullchain.pem -inkey privkey.pem -name 'bplm' -out bplm.p12
sudo gpasswd -a ${USER} docker
sed -i.bak -e "s/BPLM_VERSION/$BPLM_VERSION/g" ~/docker-compose.yml

