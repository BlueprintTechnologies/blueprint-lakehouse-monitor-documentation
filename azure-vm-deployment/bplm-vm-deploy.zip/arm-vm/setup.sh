#!/usr/bin/env bash

ADMIN_EMAIL=azureadm@bpcs.com
FQDN=<ENTER YOUR FQDN HERE>
sudo apt update
sudo apt-get install -y docker.io docker-compose
sudo apt install -y certbot

sudo certbot certonly --standalone --email ${ADMIN_EMAIL} --noninteractive --agree-tos --domain ${FQDN} --cert-name bplm
mkdir keystore
cd keystore
sudo cp -L /etc/letsencrypt/live/bplm/privkey.pem .
sudo cp -L /etc/letsencrypt/live/bplm/fullchain.pem .
sudo chown azureadm:azureadm privkey.pem fullchain.pem


openssl pkcs12 -export -in fullchain.pem -inkey privkey.pem -name 'bplm' -out bplm.p12
