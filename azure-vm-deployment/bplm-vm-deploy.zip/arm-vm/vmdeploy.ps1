<#
Param section
#>

param(

    [string]$StorageAccountName,

    [string]$KeyvaultName,

    [int]$SecretExpirationTimeinDays,

    [string]$VirtualMachineName = 'bplm-app-vm',

    [string]$VirtualMachineSize = 'Standard_B4ms',

    [string]$DNSPrefix,
    
    [Parameter(Mandatory=$true)]
    [string]$Resourcegroup,

    [Parameter(Mandatory=$true)]
    [string]$SubscriptionID,

    [Parameter(Mandatory=$true)]
    [string]$BPLM_VERSION,

    [Parameter(Mandatory=$true)]
    [string]$BaseApplicationName,

    [Parameter(Mandatory=$true)]
    [string]$ACRUsername,

    [Parameter(Mandatory=$true)]
    [string]$ACRPassword
)
Function Validate-ResourceNames{
    param (
        $ResourceList
        )
    $validationFailures = [System.Collections.ArrayList]@()
    foreach($entry in $ResourceList){
        switch ($entry.ResourceType) {
            "AppService" { #Microsoft.Web/Sites
                if($entry.ResourceName -notmatch '^[a-z0-9A-Z][a-z0-9A-Z-]{0,34}[a-z0-9A-Z]$' ){
                    $validationFailures.Add("Application name must be between 2-36 characters long, contain only alphanumerics and hyphens, and can't start or end with hyphen") | Out-Null
                }; break;
            }
            "Keyvault"{
                if($entry.ResourceName -notmatch '^[a-zA-Z](?!.*[\\-]{2})([\\w\\-]*)[-a-z0-9A-Z]{1,23}[a-z0-9A-Z]$'){
                    $validationFailures.Add("Keyvault name must be between 3 and 24 characters, include only alphanumerics and hypens, start with a letter, end with a letter or digit, and cannot contain consecutive hyphens") | Out-Null
                }
            }
            "StorageAccount"{
                if($entry.ResourceName -notmatch '^[a-z0-9]{3,24}$'){
                    $validationFailures.Add('Storage account name must be lowercase letters and numbers between 3 and 24 characters and be globally unique') | Out-Null
                }
            }
            Default {
                Write-Warning "Could not verify resource $($entry.ResourceName) of type $($entry.ResourceType)"
            }
        }
    } # end foreach
    if($validationFailures.count -gt 0){
        $count = 0
        $errorString = $validationFailures | foreach {++$count;"$count. $_`n"}
        throw "Could not validate all resource names.`n$errorString"
    }
}

$ErrorActionPreference = 'Stop'
$productName = 'Lakehouse Monitor'
Write-Output "Starting deployment for $productName"
$subContext = Set-AzContext -SubscriptionID $SubscriptionID

if(-not $StorageAccountName){
    $StorageAccountName = "$($BaseApplicationName)stg"
}
# TODO further azure resource naming validation checks
Write-Output "Replacing any '-' characters in storage account name"
$StorageAccountName = $StorageAccountName.Replace('-','')

if(-not $KeyvaultName){
    $KeyvaultName = "$($BaseApplicationName)-kv"
}

try{
    $rgCheck = Get-AzResourceGroup -Name $Resourcegroup -ErrorAction SilentlyContinue
    if(-not $rgCheck){
        throw "Could not find $Resourcegroup.  Please create the resource group before continuing with the dpeloyment."
    }
    else{
        Write-Output "Found $resourceGroup, continuing with deployment"
    }
}
catch{
    throw $_
}

if(Get-AzKeyVault -InRemovedState | where {$_.VaultName -eq $KeyVaultName}) {
    throw "Keyvault $KeyvaultName found in soft deleted state. Please purge this keyvault to continue"
}
$listToValidate = @(
    @{
        'ResourceName' = $StorageAccountName
        'ResourceType' = 'StorageAccount'
    },
    @{
        'ResourceName' = $KeyvaultName
        'ResourceType' = 'Keyvault'
    }
)
Write-Output "Validating resource names"
try{
    Validate-ResourceNames -ResourceList $listToValidate
}
catch{
    throw $_
}

Write-Output "Generating SSH key for VM access"
try{
    $keyLocation = Join-path -path "$($home)" -childpath ".ssh"
    $privateKeyPath = Join-path -path $keyLocation -childpath "$VirtualMachineName-key"
    $publicKeypath = Join-path -path $keyLocation -childpath  "$VirtualMachineName-key.pub"
    if(-not (Test-Path $keyLocation)){
        mkdir $keyLocation
    }
    ssh-keygen -m PEM -t rsa -b 2048 -C $VirtualMachineName -f $privateKeyPath
    $secureSSHKey = Get-Content $publicKeypath 
}
catch{
    $_
}

if($SecretExpirationTimeinDays){
    $ExpirationInSeconds = [int](New-Timespan '1970-01-01T00:00:00Z' ([datetime]::Now.AddDays($SecretExpirationTimeinDays))).TotalSeconds
}
$templateParameters = @{
    'ApplicationName' = $BaseApplicationName
    'storageAccountName' = $StorageAccountName
    'keyvaultName' = $KeyvaultName
    'publicSSHkey' = $secureSSHKey
    'VMName' = $VirtualMachineName
    'VMSize' = $VirtualMachineSize
}
if($ExpirationInSeconds){
    $templateParameters.Add('expirationTimeInSeconds',$ExpirationInSeconds)
}
if($DNSPrefix){
    $templateParameters.Add('dnsNamePrefix',$DNSPrefix)
}
$templateFileLocation = "$Psscriptroot\mainTemplate.bicep"
# for testing template params, templateParams.json is not checked in.  Used when testing the ui definition, which generates a json file.
#$templateParamLocation = "$Psscriptroot\templateParams.json"

$deploymentName = "$($BaseApplicationName)deployment"
try{
    Write-Output 'Starting deployment. This may take a while'
    if($templateParamLocation){
       $deploymentOutput = New-AzResourceGroupDeployment -TemplateFile $templateFileLocation -ResourceGroupName $resourcegroup -TemplateParameterFile $templateParamLocation -Name $deploymentName 
    }
    else{
       $deploymentOutput = New-AzResourceGroupDeployment -TemplateFile $templateFileLocation -ResourceGroupName $resourcegroup -TemplateParameterObject $templateParameters -Name $deploymentName
    } 
}
catch{
    throw "Could not deploy infrastructure. `n$_"
}

try{
    Write-Output "Resource deployment complete, running post-deployment configuration to create app registration, service principal, and app service authentication settings."
    $scriptParams = @{
        'BaseApplicationName' = $BaseApplicationName
        'KeyvaultName' = $KeyvaultName
        'resourcegroup' = $Resourcegroup
        'SubscriptionID' = $SubscriptionID
        'AppReplyURI' = "https://$($deploymentOutput.Outputs.vmdns.value)/login/oauth2/code/azure"
    }
    if($ExpirationInSeconds){
         $scriptParams.add('expirationTimeInSeconds',$ExpirationInSeconds)
    }
    $scriptOutput = & "$PSScriptRoot\Configure-LakehouseAD.ps1" @scriptParams
    $envConfiguration = @{
        'AppURL' = $deploymentOutput.Outputs.vmdns.value
        'TenantID' = $deploymentOutput.Outputs.tenantID.value
        'KeyvaultURL' = $deploymentOutput.Outputs.keyvaultURI.value
        'VMSysAssignedIdentity' = $deploymentOutput.Outputs.vmIdentity.value
        'AppRegistrationAppID' = $scriptOutput.AppRegistrationAppID
        'SPClientID' = $scriptOutput.SPClientID
        'SPObjectID' = $scriptOutput.SPObjectID
        'StorageAccountName'  = $deploymentOutput.Outputs.storageAccountName.value
        'containerName' = $deploymentOutput.Outputs.containerName.value
        'SQLServerURL' = $deploymentOutput.Outputs.sqlfdqn.value
        'SQLUsername' = $deploymentOutput.Outputs.sqlUsername.value
    }
    &.\Setup.ps1 @envConfiguration
    scp -o StrictHostKeyChecking=no -i $privateKeyPath setup.sh start.sh .env docker-compose.yml azureadm@$($deploymentOutput.Outputs.vmdns.value):
    ssh -o StrictHostKeyChecking=no -i $privateKeyPath -l azureadm $($deploymentOutput.Outputs.vmdns.value) bash setup.sh $($deploymentOutput.Outputs.vmdns.value) $BPLM_VERSION $ACRUsername $ACRPassword
    ssh -o StrictHostKeyChecking=no -i $privateKeyPath -l azureadm $($deploymentOutput.Outputs.vmdns.value) bash start.sh $ACRUsername $ACRPassword
    Write-Output "Deployment finished for $productName.`nGenerated SSH key can be found at $privateKeyPath`nApp URL: $($deploymentOutput.Outputs.vmdns.value)."
}
catch{
    throw $_
}
