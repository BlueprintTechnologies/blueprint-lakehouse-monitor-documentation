function Create-Zip {
    param([string[]]$FileManifest,
    [string]$Destination)
    Compress-Archive -Path $FileManifest -DestinationPath $Destination -Force
}

function Create-MarketplaceZip {
    param(
        [String]$Version = "1.1.0"
    )
    $fileList = @("$Psscriptroot\mainTemplate.json","$PsScriptRoot\createUiDefinition.json")
    $Destination = "$PSScriptRoot\marketplace-lakehouse$($Version).zip"
    Create-Zip -FileManifest $fileList -Destination $Destination
}

function Create-PostDeploymentConfigZip{
    param (
        [string]$ZipName = "postDeployConfig.zip"
    )
    $fileList = @("$Psscriptroot\postDeploymentAppService.bicep","$PsScriptRoot\Configure-LakehouseAD.ps1","$PSScriptRoot\additionalAppSettings.bicep")
    $Destination = "$PSScriptRoot\$ZipName"
    Create-Zip -FileManifest $fileList -Destination $Destination
}

function Handle-PostDeploymentConfig {
    param (
        [string]$ZipName = "postDeployConfig.zip"
    )
    Create-PostDeploymentConfigZip -ZipName $ZipName
    Connect-AzAccount -Subscription 'Blueprint Data Engine' 
    $key = Get-AzStorageAccountKey -ResourceGroupName "lho-auxresources-prod" -Name "bplmdeployment" -ErrorAction Stop -encod
    $context = New-AzStorageContext -StorageAccountName "bplmdeployment" -StorageAccountKey $key[0].Value -ErrorAction Stop
    Set-AzStorageBlobContent -File "$PSScriptRoot\$ZipName" -Container 'bplm-deployment' -Context $context -ErrorAction Stop

}
